$(document).keypress(function(event) {
    $("h1").text(event.key);
})