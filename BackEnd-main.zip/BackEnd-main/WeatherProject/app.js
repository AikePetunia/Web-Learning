const express = require("express");
const https = require("https")
const bodyParser = require("body-parser")
const app = express();

app.use(bodyParser.urlencoded({extended: true}))

app.get("/", function(req, res) {
    res.sendFile(__dirname + "/index.html")
})

app.post("/", function(req, res) {

    const location = req.body.cityName
    const apiKey = "581bf80061825eded4256ae7f78d0712"
    const unit= "metrics"
    const url = "https://api.openweathermap.org/data/2.5/weather?q="+ location +"&appid="+ apiKey +"&units=" + unit
    
    https.get(url, function(response) {
        console.log(response.statusCode);

        response.on("data", function(data) {
            const weatherData = JSON.parse(data)
            const temp = weatherData.main.temp;
            const weatherDesc = weatherData.weather[0].description;
            res.write("<p>The temperature in San Luis is " + temp +" Kelvins (idk why i can't put Degrees)</p>");
            res.write("<h1>data" + weatherDesc + " Kelvins</h1>");
            res.send();
        })
    });
    
})




app.listen(3000, function () {
    console.log("server is running in port 3000");
})