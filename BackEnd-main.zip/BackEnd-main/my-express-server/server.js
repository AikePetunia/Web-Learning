const express = require('express')
const app = express()
const port = 3000

app.get("/", function (req, res){
    res.send("<h1>hello, server!</h1>");
})

app.get("/about", function (req, res){
    res.send("HOLAA SOY AIKEE");
})

app.listen(3000, function(){
    console.log("server started at 3000");
});