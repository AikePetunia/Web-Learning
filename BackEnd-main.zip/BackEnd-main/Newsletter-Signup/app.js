// 83bd51dbacdf3580b2e462fc4fbedd1b-us21
// 14fb9a5308

const express = require("express");
const bodyParser = require("body-parser");
const request = require("request");

const app = express();

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended: true}));

app.get("/", function(req, res) {
    res.sendFile(__dirname + "/signup.html")
})

app.post("/", function(req, res) {

    const fName = req.body.fName;
    const lNname = req.body.lName;
    const pass = req.body.pass;
    const email = req.body.email;

    var data = {
        members: [
            {
                email_address: email,
                status: "suscribed",
                merge_fields: {
                    FNAME: fName,
                    LNAME: lNname,
                }
            }
        ]

    }

    var jsonData = json.stringify(data);
})

app.listen(3000, function() {
    console.log("server is runing at port 3000");
});