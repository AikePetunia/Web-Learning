Just practice.
