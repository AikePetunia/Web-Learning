# Dice-Game
Dice Game, for practice javascript
